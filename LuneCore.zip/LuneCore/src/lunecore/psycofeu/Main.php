<?php

namespace lunecore\psycofeu;

use lunecore\psycofeu\Commandes\City;
use lunecore\psycofeu\Utils\LoadServer;
use pocketmine\plugin\PluginBase;
use pocketmine\Server;
use pocketmine\utils\Config;
use pocketmine\utils\SingletonTrait;

class Main extends PluginBase
{
    use SingletonTrait;
    protected function onLoad(): void
    {
        self::setInstance($this);
        parent::onLoad();
        Server::getInstance()->getCommandMap()->register("", new City());
    }

    protected function onEnable(): void
    {
        LoadServer::LoadAll();
    }
    protected function onDisable(): void
    {
        parent::onDisable();
    }
    public function getConfigFile(string $file): Config
    {
        return new Config($this->getDataFolder() . $file . ".yml", Config::YAML);
    }
}