<?php

namespace lunecore\psycofeu\Commandes;

use lunecore\psycofeu\Commandes\Sub\CreateCitySubCommand;
use lunecore\psycofeu\Commandes\Sub\EditNameCitySubCommand;
use lunecore\psycofeu\Commandes\Sub\HelpCitySubCommand;
use lunecore\psycofeu\Lib\CortexPE\Commando\BaseCommand;
use lunecore\psycofeu\Main;
use lunecore\psycofeu\Managers\MoonPlayer;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;

class City extends BaseCommand
{
    public function __construct()
    {
        parent::__construct(Main::getInstance(), "city", "Commandes de villes", ["ville"]);
    }
    protected function prepare(): void
    {
        $this->setPermission($this->getPermission());
        $this->registerSubCommand(new HelpCitySubCommand());
        $this->registerSubCommand(new CreateCitySubCommand("create", "Crée une ville"));
        $this->registerSubCommand(new EditNameCitySubCommand());
    }
    public function getPermission(): string
    {
        return DefaultPermissions::ROOT_USER;
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if ($sender instanceof MoonPlayer){
            if ($sender->haveCity()){
                $sender->chat("/city help");
            }else $sender->sendMessage("§c- §fVous devez rejoindre ou crée une ville !");
        }
    }
}