<?php

namespace lunecore\psycofeu\Commandes\Sub;

use lunecore\psycofeu\Lib\CortexPE\Commando\args\RawStringArgument;
use lunecore\psycofeu\Lib\CortexPE\Commando\BaseSubCommand;
use lunecore\psycofeu\Main;
use lunecore\psycofeu\Managers\City\City;
use lunecore\psycofeu\Managers\City\CityManager;
use lunecore\psycofeu\Managers\MoonPlayer;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\Server;
use pocketmine\world\sound\NoteInstrument;
use pocketmine\world\sound\NoteSound;

class EditNameCitySubCommand extends BaseSubCommand
{
    public function __construct()
    {
        parent::__construct("editname", "Changé le nom de la ville", ["rename", "changename"]);
    }
    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if ($sender instanceof MoonPlayer) {
            if ($sender->haveCity()) {
                $senderCity = $sender->getCity();
                if ($senderCity instanceof City) {
                    $nom = $args["name"];
                    if (strlen($nom) < 2 or strlen($nom) > 16) {
                        $sender->sendMessage("§c- §fLe nom de l'ile doit être entre§b 2 caractères §fet§b 16 caractères §f! ");
                        return;
                    }
                    if (array_key_exists($nom, CityManager::getInstance()->city)) {
                        $sender->sendMessage("§c- §fUne ville avec le nom §c$nom §fexiste déjà !");
                        return;
                    }
                    if ($nom === "Unknown") {
                        $sender->sendMessage("§c- §fLe nom de la ville est invalide !");
                        return;
                    }
                    $old = $senderCity->name;
                    $island = CityManager::getInstance()->getCity($old);
                    if ($island instanceof City) {
                        $file = Main::getInstance()->getDataFolder() . "City/$old.yml";
                        if (file_exists($file)) {
                            unlink($file);
                        }
                        unset(CityManager::getInstance()->city[$island->name]);
                        CityManager::getInstance()->city[$nom] = $island;
                        $senderCity->name = $nom;
                        foreach ($senderCity->members as $member => $rank) {
                            $player = Server::getInstance()->getPlayerExact($member);
                            if ($player instanceof MoonPlayer && $player->isConnected()) {
                                $player->broadcastSound(new NoteSound(NoteInstrument::PIANO(), 125));
                                $player->city = $nom;
                            } else {
                                $data = Server::getInstance()->getOfflinePlayerData($member);
                                $data->setString("city", $nom);
                                Server::getInstance()->saveOfflinePlayerData($member, $data);
                            }
                        }
                        $sender->sendMessage("§b- §fLe nom de la ville vient d'être mis à jour en §b$nom §f!");
                    }
                }
            } else {
                $sender->sendMessage("§c- §fVous n'avez pas de ville");
            }
        }
    }
    protected function prepare(): void
    {
        $this->setPermission(DefaultPermissions::ROOT_USER);
        $this->registerArgument(0, new RawStringArgument("name"));
    }
}