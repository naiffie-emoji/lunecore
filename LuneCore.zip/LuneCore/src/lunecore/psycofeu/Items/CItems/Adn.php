<?php

namespace lunecore\psycofeu\Items\CItems;

use pocketmine\item\ArmorTypeInfo;
use pocketmine\item\ItemTypeIds;
use SenseiTarzan\SymplyPlugin\Behavior\Common\Enum\CategoryCreativeEnum;
use SenseiTarzan\SymplyPlugin\Behavior\Common\Enum\GroupCreativeEnum;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Armor;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Builder\ItemBuilder;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Component\DisplayNameComponent;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Info\ItemCreativeInfo;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Item;
use SenseiTarzan\SymplyPlugin\Behavior\Items\ItemIdentifier;

class Adn extends Item
{

    public function __construct()
    {
        parent::__construct(new ItemIdentifier("moon:adn", ItemTypeIds::newId()), "§b- §fADN§b -");
    }

    public function getItemBuilder(): ItemBuilder
    {
        return parent::getItemBuilder()
            ->setIcon("adn")
            ->addComponent(new DisplayNameComponent($this->getVanillaName()))
            ->setCreativeInfo(new ItemCreativeInfo(CategoryCreativeEnum::ITEMS, GroupCreativeEnum::NONE));
    }
}