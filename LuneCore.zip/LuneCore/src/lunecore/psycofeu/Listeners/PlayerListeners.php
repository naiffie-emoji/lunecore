<?php

namespace lunecore\psycofeu\Listeners;

use lunecore\psycofeu\Items\CItems\Trident;
use lunecore\psycofeu\Items\MoonItems;
use lunecore\psycofeu\Managers\MoonPlayer;
use pocketmine\block\BlockTypeIds;
use pocketmine\block\Dirt;
use pocketmine\block\utils\DirtType;
use pocketmine\block\VanillaBlocks;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerCreationEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\item\Item;
use pocketmine\item\ItemTypeIds;
use pocketmine\item\VanillaItems;

class PlayerListeners implements Listener
{
    public function onJoin(PlayerJoinEvent $event): void
    {
        $event->setJoinMessage("§a[+] §f- " . $event->getPlayer()->getName());
    }
    public function onLeave(PlayerQuitEvent $event): void
    {
        $event->setQuitMessage("§c[-] §f- " . $event->getPlayer()->getName());
    }
    public function playerInteractEvent(PlayerInteractEvent $event): void
    {
        $block = $event->getBlock();
        if ($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_BLOCK){
            if ($block instanceof Dirt && $block->getDirtType() === DirtType::COARSE){
                $rand = rand(1,100);
                if ($rand <= 5){
                    $block->getPosition()->getWorld()->dropItem($block->getPosition(), VanillaBlocks::OAK_LEAVES()->asItem());
                }elseif($rand <= 7)  $block->getPosition()->getWorld()->dropItem($block->getPosition(), MoonItems::ADN());
            }

        }
    }
    public function onCreat(PlayerCreationEvent $event): void
    {
        $event->setPlayerClass(MoonPlayer::class);
    }

    public function BlockBreakEvent(BlockBreakEvent $event): void
    {
        $block = $event->getBlock();
        $player = $event->getPlayer();
        if ($block->getTypeId() !== BlockTypeIds::END_STONE) return;

        $randomIterator = rand(0, 100);
        $pickaxeDrops = [
            ItemTypeIds::STONE_PICKAXE => [
                2 => VanillaItems::IRON_INGOT(),
                4 => VanillaItems::COPPER_INGOT(),
                9 => VanillaItems::GUNPOWDER(),
                14 => VanillaItems::AMETHYST_SHARD(),
                19 => VanillaBlocks::AMETHYST()->asItem(),
                24 => VanillaBlocks::BONE_BLOCK()->asItem(),
                29 => VanillaItems::NETHER_QUARTZ(),
            ],
            ItemTypeIds::IRON_PICKAXE => [
                1 => VanillaItems::DIAMOND(),
                4 => VanillaItems::IRON_INGOT(),
                7 => VanillaItems::COPPER_INGOT(),
                12 => VanillaItems::GUNPOWDER(),
                17 => VanillaItems::AMETHYST_SHARD(),
                22 => VanillaBlocks::AMETHYST()->asItem(),
                27 => VanillaBlocks::BONE_BLOCK()->asItem(),
                32 => VanillaItems::NETHER_QUARTZ(),
            ],
            ItemTypeIds::DIAMOND_PICKAXE => [
                1 => VanillaItems::DIAMOND(),
                2 => MoonItems::TRIDENT(),
                3 => MoonItems::TRIDENT_AMETHYSTE(),
                4 => MoonItems::TRIDENT_COPPER(),
                7 => VanillaItems::IRON_INGOT(),
                10 => VanillaItems::COPPER_INGOT(),
                15 => VanillaItems::GUNPOWDER(),
                22 => VanillaItems::AMETHYST_SHARD(),
                27 => VanillaBlocks::AMETHYST()->asItem(),
                31 => VanillaBlocks::BONE_BLOCK()->asItem(),
                36 => VanillaItems::NETHER_QUARTZ(),
            ]
        ];

        $handItem = $player->getInventory()->getItemInHand()->getTypeId();
        if (!isset($pickaxeDrops[$handItem])) {
            if ($randomIterator > 25) $player->getWorld()->dropItem($block->getPosition(), $block->asItem());
            return;
        }

        foreach ($pickaxeDrops[$handItem] as $threshold => $item) {
            if ($item instanceof Item) {
                if (($item->getTypeId() === ItemTypeIds::DIAMOND && random_int(0, 10) !== 9) ||
                    ($item instanceof Trident && random_int(0, 100) !== 9)) {
                    continue;
                }
            }
            if ($randomIterator < $threshold) {
                $event->setDrops([$item]);
                return;
            }
        }
    }

}