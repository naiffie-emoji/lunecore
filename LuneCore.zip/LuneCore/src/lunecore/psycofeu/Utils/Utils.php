<?php

namespace lunecore\psycofeu\Utils;

use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\player\Player;
use pocketmine\world\Position;

class Utils
{
    public static function sendSoundPacket(Player $player, string $sound, float $volume = 1): void
    {
        $packet = new PlaySoundPacket();
        $packet->x = $player->getPosition()->getX();
        $packet->y = $player->getPosition()->getY();
        $packet->z = $player->getPosition()->getZ();
        $packet->volume = $volume;
        $packet->pitch = 0.6;
        $packet->soundName = $sound;
        $player->getNetworkSession()->sendDataPacket($packet);
    }
    public static function broadCastSoundPacket(Position $position, string $sound, float $volume = 1, float $maxDistance = 15): void
    {
        $packet = new PlaySoundPacket();
        $packet->x = $position->getX();
        $packet->y = $position->getY();
        $packet->z = $position->getZ();
        $packet->volume = $volume;
        $packet->pitch = 0.6;
        $packet->soundName = $sound;
        foreach ($position->getWorld()->getPlayers() as $player) {
            $distance = $player->getPosition()->distance($position);
            if ($distance > $maxDistance) continue;
            $adjustedVolume = $volume * (1 - ($distance / $maxDistance));
            if ($adjustedVolume <= 0) continue;
            $packet->volume = $adjustedVolume;
            $player->getNetworkSession()->sendDataPacket($packet);
        }
    }
}