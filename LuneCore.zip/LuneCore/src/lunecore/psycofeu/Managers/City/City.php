<?php

namespace lunecore\psycofeu\Managers\City;

use pocketmine\player\Player;
use pocketmine\Server;

class City
{
    public function __construct(
        public string $name,
        public string $lore,
        public string $world,
        public bool $status,
        public array $members,
        public string $position,
        public array $claimPositions,
        public array $ranks,
        public string $creation,
    ){}
    public function serialize(): array
    {
        return [
            "name" => $this->name,
            "lore" => $this->lore,
            "world" => $this->world,
            "status" => $this->status,
            "members" => $this->members,
            "position" => $this->position,
            "claimPositions" => $this->claimPositions,
            "ranks" => $this->ranks,
            "creation" => $this->creation,
        ];
    }
    public static function unserialize(array $data): City
    {
        return new self($data["name"], $data["lore"], $data["world"], $data["status"], $data["members"], $data["position"], $data["claimPosition"], $data["ranks"], $data["creation"]);
    }

    public function sendMessage(string $message): void
    {
        foreach ($this->members as $member => $rank){
            $player = Server::getInstance()->getPlayerExact($member);
            if ($player instanceof Player && $player->isOnline()){
                $player->sendMessage($message);
            }
        }
    }
}