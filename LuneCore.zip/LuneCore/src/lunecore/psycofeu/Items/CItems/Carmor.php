<?php

namespace lunecore\psycofeu\Items\CItems;

use pocketmine\item\ArmorTypeInfo;
use pocketmine\item\ItemTypeIds;
use SenseiTarzan\SymplyPlugin\Behavior\Common\Enum\CategoryCreativeEnum;
use SenseiTarzan\SymplyPlugin\Behavior\Common\Enum\GroupCreativeEnum;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Armor;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Builder\ItemBuilder;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Component\DisplayNameComponent;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Info\ItemCreativeInfo;
use SenseiTarzan\SymplyPlugin\Behavior\Items\ItemIdentifier;

class Carmor extends Armor
{
    public string $texture = "";

    public function __construct(string $name, string $texture, string $protection, int $durability, int $slot, string $displayName)
    {
        $this->texture = $texture;
        parent::__construct(new ItemIdentifier("moon:" . str_replace(" ", "_", strtolower($name)), ItemTypeIds::newId()), "§b- §f" . $displayName . "§b -", new ArmorTypeInfo($protection, $durability, $slot, 0, false));
    }

    public function getItemBuilder(): ItemBuilder
    {
        return parent::getItemBuilder()
            ->setIcon($this->texture)
            ->addComponent(new DisplayNameComponent($this->getVanillaName()))
            ->setCreativeInfo(new ItemCreativeInfo(CategoryCreativeEnum::ITEMS, GroupCreativeEnum::NONE));
    }
}