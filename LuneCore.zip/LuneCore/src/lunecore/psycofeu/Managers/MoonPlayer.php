<?php

namespace lunecore\psycofeu\Managers;

use lunecore\psycofeu\Managers\City\City;
use lunecore\psycofeu\Managers\City\CityManager;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\entity\Location;
use pocketmine\item\VanillaItems;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\network\mcpe\NetworkSession;
use pocketmine\player\Player;
use pocketmine\player\PlayerInfo;
use pocketmine\Server;

class MoonPlayer extends Player
{

    public int $oxygene = 33;
    public string $city = "Unknown";
    public function __construct(Server $server, NetworkSession $session, PlayerInfo $playerInfo, bool $authenticated, Location $spawnLocation, ?CompoundTag $namedtag)
    {
        parent::__construct($server, $session, $playerInfo, $authenticated, $spawnLocation, $namedtag);
        $this->city = $namedtag?->getString("city", "Unknown") ?? "Unknown";
    }
    public function getSaveData(): CompoundTag
    {
        $nbt = parent::getSaveData();
        $nbt->setString("city", $this->city);
        return $nbt;
    }
    public function checkOxygene(): void
    {
        if ((!$this->getArmorInventory()->getHelmet()->isNull()) && $this->getArmorInventory()->getHelmet()->getTypeId() !== VanillaItems::AIR()->getTypeId()) {
            if ($this->oxygene !== 33) {
                $this->oxygene++;
            }
        }else {
            if ($this->oxygene <= 0) {
                $this->getEffects()->add(new EffectInstance(VanillaEffects::NAUSEA(), 3*20, 1, false));
                $this->getEffects()->add(new EffectInstance(VanillaEffects::WITHER(), 3*20, 1, false));
                $this->sendTip("Oxygene: §c" . str_repeat("|", round((33 - $this->oxygene))));
                return;
            } else {
                $this->oxygene--;
            }
        }
        $this->sendTip("Oxygene: §a" . str_repeat("|", round($this->oxygene)) . "§c" . str_repeat("|", round((33 - $this->oxygene))));

    }

    public function onUpdate(int $currentTick): bool
    {
        if (Server::getInstance()->getTick() % 10 === 0){
            $this->checkOxygene();
        }
        return parent::onUpdate($currentTick);
    }
    public function haveCity(): bool
    {
        if ($this->city === "Unknown") return false;
        return true;
    }
    public function getCity(): ?City
    {
        return CityManager::getInstance()->getCity($this->city);
    }
}