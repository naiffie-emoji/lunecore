<?php

namespace lunecore\psycofeu\Enchantment;

use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\Rarity;
use pocketmine\utils\CloningRegistryTrait;

/**
 * @method static Enchantment RIPTIDE
 */
class Cenchant
{
    use CloningRegistryTrait;
    protected static function setup(): void
    {
        self::_registryRegister("riptide", new Riptide("Riptide", Rarity::RARE, 0,
            0,
            5,
            fn(int $level) : int => 11 * ($level - 1) + 1,
            20));
    }
}