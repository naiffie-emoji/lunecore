<?php

namespace lunecore\psycofeu\Commandes\Sub;

use lunecore\psycofeu\Lib\CortexPE\Commando\args\RawStringArgument;
use lunecore\psycofeu\Lib\CortexPE\Commando\BaseSubCommand;
use lunecore\psycofeu\Managers\City\City;
use lunecore\psycofeu\Managers\City\CityManager;
use lunecore\psycofeu\Managers\MoonPlayer;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;

class CreateCitySubCommand extends BaseSubCommand
{

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        $player = $sender;

        if ($player instanceof MoonPlayer) {
            if (empty($args["name"])) {
                $sender->sendMessage("§c- §fUtilisation: /city create §c%%name%%");
                return;
            }
            $nom = $args["name"];
            if ($player->haveCity()) {
                $player->sendMessage("§c- §fVous possédez déjà une ville !");
            } else {
                if (array_key_exists($nom, CityManager::getInstance()->city)) {
                    $player->sendMessage("§c- §fUne ville avec le nom §c$nom §fexiste déjà !");
                    return;
                }
                $regexp = '/^[a-zA-Z0-9]+$/';
                if (!preg_match($regexp, $nom)) {
                    $player->sendMessage("§c- §fLe nom de la ville peut uniquement contenir des lettres (majuscule/minuscule) et des chiffres !");
                    return;
                }
                if (strlen($nom) < 2 or strlen($nom) > 16) {
                    $player->sendMessage("§c- §fLe nom de de la ville doit avoir entre §c2 caractères §fet§c 16 caractères§f !");
                    return;
                }
                if ($nom === "Unknown") {
                    $player->sendMessage("§c- §fLe nom de la ville invalide !");
                    return;
                }
                $player->city = $nom;
                $creation = date("d/m/Y");
                $city = new City($nom, "", $player->getWorld()->getFolderName(), false, [$player->getName() => "chef"], "", [], ["default" => ["build.claim", "pvp.claim", "open_chest.claim", "tp.city"]], $creation);
                CityManager::getInstance()->city[$nom] = $city;
                $player->sendMessage("§b- §fVotre ville vient d'être crée avec le nom §b$nom §f!");
            }
        }
    }

    protected function prepare(): void
    {
        $this->setPermission(DefaultPermissions::ROOT_USER);
        $this->registerArgument(0, new RawStringArgument("name", true));
    }
}