<?php

namespace lunecore\psycofeu\Utils;

use lunecore\psycofeu\Entitys\TridentEntity;
use lunecore\psycofeu\Items\MoonItems;
use lunecore\psycofeu\Listeners\PlayerListeners;
use lunecore\psycofeu\Main;
use pocketmine\block\VanillaBlocks;
use pocketmine\crafting\ExactRecipeIngredient;
use pocketmine\crafting\FurnaceRecipe;
use pocketmine\crafting\FurnaceType;
use pocketmine\entity\EntityDataHelper;
use pocketmine\entity\EntityFactory;
use pocketmine\item\VanillaItems;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\Server;
use pocketmine\world\World;
use SenseiTarzan\SymplyPlugin\Behavior\SymplyItemFactory;

class LoadServer
{
    public static function LoadAll(): void
    {
        self::loadEntity();
        self::loadItem();
        self::loadCrafts();
        Main::getInstance()->getServer()->getPluginManager()->registerEvents(new PlayerListeners(), Main::getInstance());
    }
    public static function loadItem(): void
    {
        $factory = SymplyItemFactory::getInstance();


        $factory->register(static fn() => MoonItems::TRIDENT());
        $factory->register(static fn() => MoonItems::TRIDENT_AMETHYSTE());
        $factory->register(static fn() => MoonItems::TRIDENT_COPPER());

        $factory->register(static fn() => MoonItems::AMETHYSTE_HELMET());
        $factory->register(static fn() => MoonItems::AMETHYSTE_CHESTPLATE());
        $factory->register(static fn() => MoonItems::AMETHYSTE_LEGGINGS());
        $factory->register(static fn() => MoonItems::AMETHYSTE_BOOTS());

        $factory->register(static fn() => MoonItems::COPPER_HELMET());
        $factory->register(static fn() => MoonItems::COPPER_CHESTPLATE());
        $factory->register(static fn() => MoonItems::COPPER_LEGGINGS());
        $factory->register(static fn() => MoonItems::COPPER_BOOTS());

        $factory->register(static fn() => MoonItems::METAL_HELMET());
        $factory->register(static fn() => MoonItems::METAL_CHESTPLATE());
        $factory->register(static fn() => MoonItems::METAL_LEGGINGS());
        $factory->register(static fn() => MoonItems::METAL_BOOTS());

        $factory->register(static fn() => MoonItems::DIAMANT_BRUT_HELMET());
        $factory->register(static fn() => MoonItems::DIAMANT_BRUT_CHESTPLATE());
        $factory->register(static fn() => MoonItems::DIAMANT_BRUT_LEGGINGS());
        $factory->register(static fn() => MoonItems::DIAMANT_BRUT_BOOTS());

        $factory->register(static fn() => MoonItems::ADN());
    }
    public static function loadEntity(): void
    {
        EntityFactory::getInstance()->register(TridentEntity::class, function (World $world, CompoundTag $nbt): TridentEntity {
            return new TridentEntity(EntityDataHelper::parseLocation($nbt, $world), MoonItems::TRIDENT(), null, 8, false);
        }, ['Trident', 'ThrownTrident', 'minecraft:trident' , 'minecraft:trown_trident']);
    }
    public static function loadCrafts(): void
    {
        $furnaceRecepies = Server::getInstance()->getCraftingManager()->getFurnaceRecipeManager(FurnaceType::FURNACE);

        $furnaceRecepies->register(new FurnaceRecipe(VanillaItems::NETHER_STAR(), new ExactRecipeIngredient(VanillaBlocks::END_STONE()->asItem())));
        $furnaceRecepies->register(new FurnaceRecipe(VanillaItems::CLAY(), new ExactRecipeIngredient(VanillaItems::NETHER_STAR())));
    }
}