<?php

namespace lunecore\psycofeu\Commandes\Sub;

use lunecore\psycofeu\Lib\CortexPE\Commando\BaseSubCommand;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;

class HelpCitySubCommand extends BaseSubCommand
{
    public function __construct()
    {
        parent::__construct("help", "Voir la liste des commandes de ville", ["sos"]);
    }
    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        $sender->sendMessage("§7- §fMoon HelpCitySubCommand §7-\n" .
            "§7- §f/city: Commande basic du systeme de ville\n" .
            "§7- §f/city create %%name%%: Créer une ville\n" .
            "§7- §f/city edit name %%newname%%: Modifier le nom de la ville\n" .
            "§7- §f/city disband: Supprimer totalement la ville\n" .
            "§7- §f/city transfer %%player%%: Donner la propriété à un autre joueur\n" .
            "§7- §f/city leave: Quitter la ville\n" .
            "§7- §f/city edit lore %%newlore%%: Modifier/ajouter une description\n" .
            "§7- §f/city edit visibility %%public/private%%: Définir la visibilité\n" .
            "§7- §f/city sethome: Définir le point de téléportation\n" .
            "§7- §f/city invite %%player%%: Inviter un joueur\n" .
            "§7- §f/city join %%cityname%%: Rejoindre une ville\n" .
            "§7- §f/city accept: Accepter une invitation\n" .
            "§7- §f/city deny: Refuser une invitation\n" .
            "§7- §f/city kick %%player%%: Expulser un joueur\n" .
            "§7- §f/city claim: Sécuriser une zone\n" .
            "§7- §f/city rank create %%name%%: Créer un grade\n" .
            "§7- §f/city rank edit %%namerank%% name %%newname%%: Modifier le nom d'un grade\n" .
            "§7- §f/city rank edit %%namerank%% perm %%permission%%: Modifier les permissions d'un grade\n" .
            "§7- §f/city user %%rank%% add: Donner un grade à un joueur\n" .
            "§7- §f/city user %%rank%% remove: Retirer un grade à un joueur\n");
    }
    protected function prepare(): void
    {
        $this->setPermission($this->getPermission());
    }
    public function getPermission(): string
    {
        return DefaultPermissions::ROOT_USER;
    }
}