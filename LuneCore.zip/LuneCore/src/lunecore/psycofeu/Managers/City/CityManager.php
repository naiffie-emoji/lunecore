<?php

namespace lunecore\psycofeu\Managers\City;

use lunecore\psycofeu\Main;
use pocketmine\utils\SingletonTrait;

class CityManager
{
    use SingletonTrait;

    public static array $cityInvite = [];
    public array $city = [];
    public function getCity(string $name): ?City
    {
        return $this->city[$name] ?? null;
    }
    public function register():void
    {
        $scan = scandir(Main::getInstance()->getDataFolder() . "City/");
        foreach ($scan as $file){
            if (is_file(Main::getInstance()->getDataFolder() . "City/" . $file)){
                $f = substr($file, 0, -4);
                $config = Main::getInstance()->getConfigFile("City/$f");
                $sb = City::unserialize($config->getAll());
                $this->city[$config->get("name")] = $sb;
            }
        }
    }
    public function save(): void
    {
        foreach ($this->city as $name => $island) {
            $config = Main::getInstance()->getConfigFile("City/$name");
            $config->setAll($this->getCity($name)->serialize());
            $config->save();
        }
    }

}