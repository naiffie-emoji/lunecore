<?php

namespace lunecore\psycofeu\Items\CItems;

use lunecore\psycofeu\Enchantment\Cenchant;
use lunecore\psycofeu\Entitys\TridentEntity;
use lunecore\psycofeu\Utils\Utils;
use pocketmine\block\Block;
use pocketmine\entity\Entity;
use pocketmine\entity\Location;
use pocketmine\event\entity\ProjectileLaunchEvent;
use pocketmine\item\enchantment\ItemEnchantmentTags;
use pocketmine\item\ItemTypeIds;
use pocketmine\item\ItemUseResult;
use pocketmine\item\Releasable;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use SenseiTarzan\SymplyPlugin\Behavior\Common\Enum\CategoryCreativeEnum;
use SenseiTarzan\SymplyPlugin\Behavior\Common\Enum\GroupCreativeEnum;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Builder\ItemBuilder;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Component\DisplayNameComponent;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Component\ShooterComponent;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Component\sub\AmmunitionSubComponent;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Component\UseAnimationComponent;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Component\UseModifiersComponent;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Enum\AnimationEnum;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Info\ItemCreativeInfo;
use SenseiTarzan\SymplyPlugin\Behavior\Items\ItemIdentifier;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Property\DamageProperty;

class Trident extends \SenseiTarzan\SymplyPlugin\Behavior\Items\Durable implements Releasable
{
    public string $type = "";
    public float $damages = 0;
    public float $durabilitys = 0;
    public function __construct(string $type, float $damage, float $durability)
    {
        $this->damages = $damage;
        $this->durabilitys = $durability;
        $this->type = $type;
        parent::__construct(new ItemIdentifier("moon:trident_$type", ItemTypeIds::newId()), "Trident " . ucfirst($type), [ItemEnchantmentTags::TRIDENT]);
        $this->setLore(["§9$damage attack point"]);
    }
    public function getMaxStackSize(): int
    {
        return 1;
    }

    public function getItemBuilder(): ItemBuilder
    {
        return parent::getItemBuilder()
            ->setIcon("trident")
            ->setCreativeInfo(new ItemCreativeInfo(CategoryCreativeEnum::EQUIPMENT, GroupCreativeEnum::SWORD))
            ->addComponent(new DisplayNameComponent($this->getVanillaName()))
            ->addProperty(new DamageProperty($this->damage))
            ->addComponent(new UseAnimationComponent(AnimationEnum::SPEAR))
            ->addComponent(new UseModifiersComponent(100, 0.5))
            ->addComponent(new ShooterComponent([new AmmunitionSubComponent("minecraft:trident")], true, 1.0, true));
    }
    public function onReleaseUsing(Player $player, array &$returnedItems): ItemUseResult
    {
        $location = $player->getLocation();
        $diff = $player->getItemUseDuration();
        $p = $diff / 20;
        $baseForce = min((($p ** 2) + $p * 2) / 3, 1) * 3;
        if ($baseForce < 0.9 || $diff < 8) {
            return ItemUseResult::FAIL();
        }
        $follow = false;
        foreach ($this->getEnchantments() as $_ => $enchantment) {
            if ($enchantment->getType() === Cenchant::RIPTIDE()) $follow = true;
        }
        $entity = new TridentEntity(Location::fromObject(
            $player->getEyePos(),
            $player->getWorld(),
            ($location->yaw > 180 ? 360 : 0) - $location->yaw,
            -$location->pitch
        ), $this, $player, $this->damages, $follow);
        $entity->setMotion($player->getDirectionVector()->multiply($baseForce));

        $ev = new ProjectileLaunchEvent($entity);
        $ev->call();
        if ($ev->isCancelled()) {
            $ev->getEntity()->flagForDespawn();
            return ItemUseResult::FAIL();
        }
        $ev->getEntity()->spawnToAll();
        Utils::broadCastSoundPacket($player->getPosition(), "item.trident.throw");


        if ($player->hasFiniteResources()) {
            $item = $entity->getItem();
            $item->applyDamage(1);
            $entity->setItem($this);
            $player->getInventory()->setItemInHand(VanillaItems::AIR());
        } else {
            $entity->setPickupMode(0);
        }
        return ItemUseResult::SUCCESS();
    }


    public function getAttackPoints(): int
    {
        return 8;
    }

    public function onDestroyBlock(Block $block, array &$returnedItems): bool
    {
        if(!$block->getBreakInfo()->breaksInstantly()){
            $this->applyDamage(2);
        }
        return false;
    }

    public function onAttackEntity(Entity $victim, array &$returnedItems): bool
    {
        $this->applyDamage(1);
        return parent::onAttackEntity($victim, $returnedItems);
    }

    public function canStartUsingItem(Player $player) : bool{
        return true;
    }

    public function getMaxDurability(): int
    {
        return $this->durabilitys;
    }
}