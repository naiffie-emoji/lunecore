<?php

namespace lunecore\psycofeu\Entitys;

use lunecore\psycofeu\Items\CItems\Trident;
use lunecore\psycofeu\Utils\Utils;
use pocketmine\block\Block;
use pocketmine\entity\Entity;
use pocketmine\entity\EntitySizeInfo;
use pocketmine\entity\Location;
use pocketmine\entity\projectile\Projectile;
use pocketmine\event\entity\EntityItemPickupEvent;
use pocketmine\item\Item;
use pocketmine\math\RayTraceResult;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\network\mcpe\protocol\types\entity\EntityIds;
use pocketmine\player\Player;

class TridentEntity extends Projectile {

    public static function getNetworkTypeId(): string
    {
        return EntityIds::THROWN_TRIDENT;
    }

    public const PICKUP_NONE = 0;
    public const PICKUP_ANY = 1;
    public const PICKUP_CREATIVE = 2;

    private const TAG_PICKUP = "pickup";

    protected $item;

    protected float $gravity = 0.05;
    protected float $drag = 0.01;
    protected float $damage = 8.0;
    protected int $pickupMode = self::PICKUP_ANY;
    protected bool $canHitEntity = true;
    public bool $follow = false;
    public ?Entity $shooter;
    public function __construct(Location $location, Trident $item, ?Entity $shootingEntity, float $damage,  bool $follow = false, ?CompoundTag $nbt = null)
    {
        $this->shooter = $shootingEntity;
        $this->damage = $damage;
        $this->follow = $follow;
        if ($item->isNull()) {
            throw new \InvalidArgumentException("Une erreur s'est produite lors de la création du trident !");
        }
        $this->setItem($item);
        parent::__construct($location, $shootingEntity, $nbt);
    }

    protected function getInitialSizeInfo(): EntitySizeInfo
    {
        return new EntitySizeInfo(0.25, 0.25);
    }


    protected function initEntity(CompoundTag $nbt): void
    {
        parent::initEntity($nbt);

        $this->pickupMode = $nbt->getByte(self::TAG_PICKUP, self::PICKUP_ANY);
        $this->canHitEntity = $nbt->getByte("canHitEntity", 1) === 1;
        if ($nbt->getTag("string") instanceof StringTag){
            if (!is_null($nbt->getString("item")) && $nbt->getString("item", "") !== false && $nbt->getString("item", "") !== ""){
                $this->item = Item::nbtDeserialize(unserialize(base64_decode($nbt->getString("item", "") === "")));
            }

        }
    }

    public function saveNBT(): CompoundTag
    {
        $nbt = parent::saveNBT();
        $nbt->setTag("item", $this->item->nbtSerialize());
        $nbt->setByte(self::TAG_PICKUP, $this->pickupMode);
        $nbt->setByte("canHitEntity", $this->canHitEntity ? 1 : 0);
        $nbt->setString("item", base64_encode(serialize($this->item->nbtSerialize() ?? "")),);
        return $nbt;
    }

    protected function entityBaseTick(int $tickDiff = 1): bool
    {
        if ($this->follow){
            $entity = $this->shooter;
            if ($entity instanceof Player && $entity->isOnline()){
                $entity->teleport($this->location);
            }
        }
        if ($this->closed) {
            return false;
        }

        return parent::entityBaseTick($tickDiff);
    }

    public function move(float $dx, float $dy, float $dz): void
    {
        parent::move($dx, $dy, $dz);
        $motion = $this->motion;
        if ($this->isCollided && !$this->canHitEntity) {
            $this->motion = $motion;
        }

    }


    protected function onHitEntity(Entity $entityHit, RayTraceResult $hitResult): void
    {
        if (!$this->canHitEntity) {
            return;
        }
        if ($entityHit->getId() === $this->ownerId) {
            if ($entityHit instanceof Player) {
                $this->pickup($entityHit);
                return;
            }
        }
        parent::onHitEntity($entityHit, $hitResult);
        $this->canHitEntity = false;
        $this->item->applyDamage(1);
        $newTrident = new self($this->location, $this->item, $this->getOwningEntity(), $this->damage);
        $newTrident->spawnToAll();
        $motion = new Vector3($this->motion->x * -0.01, $this->motion->y * -0.1, $this->motion->z * -0.01);
        $newTrident->setMotion($motion);
        Utils::broadCastSoundPacket($this->getPosition(), "item.trident.hit");
    }

    protected function onHitBlock(Block $blockHit, RayTraceResult $hitResult): void
    {
        parent::onHitBlock($blockHit, $hitResult);
        $this->canHitEntity = true;
        Utils::broadCastSoundPacket($this->getPosition(), "item.trident.hit_ground");
    }

    public function getItem(): Trident
    {
        return clone $this->item;
    }

    public function setItem(Trident $item): void
    {
        if ($item->isNull()) {
            throw new \InvalidArgumentException("Une erreur s'est produite lors de la destruction du trident !");
        }
        $this->item = clone $item;
        $this->networkPropertiesDirty = true;
    }

    public function getPickupMode(): int
    {
        return $this->pickupMode;
    }

    public function setPickupMode(int $pickupMode): void
    {
        $this->pickupMode = $pickupMode;
    }

    public function onCollideWithPlayer(Player $player): void
    {
        if ($this->blockHit === null) {
            return;
        }

        $this->pickup($player);
    }

    private function pickup(Player $player): void
    {
        $item = $this->getItem();
        $playerInventory = match (true) {
            $player->getInventory()->getAddableItemQuantity($item) > 0 => $player->getInventory(),
            default => null
        };
        $ev = new EntityItemPickupEvent($player, $this, $item, $playerInventory);
        if ($player->hasFiniteResources() and $playerInventory === null) {
            $ev->cancel();
        }
        if ($this->pickupMode === self::PICKUP_NONE or ($this->pickupMode === self::PICKUP_CREATIVE and !$player->isCreative())) {
            $ev->cancel();
            $this->flagForDespawn();
        }

        $ev->call();
        if (!$ev->isCancelled()) {
            $ev->getInventory()?->addItem($ev->getItem());
            $this->flagForDespawn();
        }
    }

    protected function getInitialDragMultiplier(): float
    {
        return 0.01;
    }

    protected function getInitialGravity(): float
    {
        return 0.05;
    }
}