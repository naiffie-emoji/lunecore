<?php

namespace lunecore\psycofeu\Enchantment;

use pocketmine\item\enchantment\Enchantment;

class Riptide extends Enchantment {}