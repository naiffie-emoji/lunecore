<?php

namespace lunecore\psycofeu\Items;

use lunecore\psycofeu\Items\CItems\Adn;
use lunecore\psycofeu\Items\CItems\Carmor;
use lunecore\psycofeu\Items\CItems\Trident;
use pocketmine\inventory\ArmorInventory;
use pocketmine\utils\CloningRegistryTrait;

/**
 * @method static Trident TRIDENT
 * @method static Trident TRIDENT_AMETHYSTE
 * @method static Trident TRIDENT_COPPER
 *
 * @method static CArmor AMETHYSTE_HELMET
 * @method static CArmor AMETHYSTE_CHESTPLATE
 * @method static CArmor AMETHYSTE_LEGGINGS
 * @method static CArmor AMETHYSTE_BOOTS
 *
 * @method static CArmor COPPER_HELMET
 * @method static CArmor COPPER_CHESTPLATE
 * @method static CArmor COPPER_LEGGINGS
 * @method static CArmor COPPER_BOOTS
 *
 * @method static CArmor METAL_HELMET
 * @method static CArmor METAL_CHESTPLATE
 * @method static CArmor METAL_LEGGINGS
 * @method static CArmor METAL_BOOTS
 *
 * @method static CArmor DIAMANT_BRUT_HELMET
 * @method static CArmor DIAMANT_BRUT_CHESTPLATE
 * @method static CArmor DIAMANT_BRUT_LEGGINGS
 * @method static CArmor DIAMANT_BRUT_BOOTS
 * @method static Adn ADN
 */
final class MoonItems
{
    use CloningRegistryTrait;
    public static function getAll() : array{
        $result = self::_registryGetAll();
        return $result;
    }
    protected static function setup(): void
    {

        // Tridents
        self::_registryRegister("trident", new Trident("basic", 8, 850));
        self::_registryRegister("trident_amethyste", new Trident("amethyste", 19.5, 1500));
        self::_registryRegister("trident_copper", new Trident("copper", 14.5, 1250));

        // Autre

        self::_registryRegister("adn", new Adn());

        // 	Armures

        self::_registryRegister("amethyste_helmet", new CArmor("Amethyste Helmet", "amethyste_helmet", 3, 2450, ArmorInventory::SLOT_HEAD, "Casque en §6Amethyste"));
        self::_registryRegister("amethyste_chestplate", new CArmor("Amethyste Chestplate", "amethyste_chestplate", 8, 2450, ArmorInventory::SLOT_CHEST, "Plastron en §6Amethyste"));
        self::_registryRegister("amethyste_leggings", new CArmor("Amethyste Leggings", "amethyste_leggings", 6, 2450, ArmorInventory::SLOT_LEGS, "Jambiers en §6Amethyste"));
        self::_registryRegister("amethyste_boots", new CArmor("Amethyste Boots", "amethyste_boots", 3, 2450, ArmorInventory::SLOT_FEET, "Bottes en §6Amethyste"));

        self::_registryRegister("copper_helmet", new CArmor("Copper Helmet", "copper_helmet", 2, 800, ArmorInventory::SLOT_HEAD, "Casque en §nCuivre"));
        self::_registryRegister("copper_chestplate", new CArmor("Copper Chestplate", "copper_chestplate", 6, 800, ArmorInventory::SLOT_CHEST, "Plastron en §nCuivre"));
        self::_registryRegister("copper_leggings", new CArmor("Copper Leggings", "copper_leggings", 5, 800, ArmorInventory::SLOT_LEGS, "Jambiers en §nCuivre"));
        self::_registryRegister("copper_boots", new CArmor("Copper Boots", "copper_boots", 2, 800, ArmorInventory::SLOT_FEET, "Bottes en §nCuivre"));

        self::_registryRegister("metal_helmet", new CArmor("Metal Helmet", "metal_helmet", 4, 3000, ArmorInventory::SLOT_HEAD, "Casque en §7Métal"));
        self::_registryRegister("metal_chestplate", new CArmor("Metal Chestplate", "metal_chestplate", 9, 3000, ArmorInventory::SLOT_CHEST, "Plastron en §7Métal"));
        self::_registryRegister("metal_leggings", new CArmor("Metal Leggings", "metal_leggings", 7, 3000, ArmorInventory::SLOT_LEGS, "Jambiers en §7Métal"));
        self::_registryRegister("metal_boots", new CArmor("Metal Boots", "metal_boots", 4, 3000, ArmorInventory::SLOT_FEET, "Bottes en §7Métal"));

        self::_registryRegister("diamant_brut_helmet", new CArmor("Diamant Brut Helmet", "diamant_brut_helmet", 5, 5000, ArmorInventory::SLOT_HEAD, "Casque en §bDiamant Brut"));
        self::_registryRegister("diamant_brut_chestplate", new CArmor("Diamant Brut Chestplate", "diamant_brut_chestplate", 10, 5000, ArmorInventory::SLOT_CHEST, "Plastron en §bDiamant Brut"));
        self::_registryRegister("diamant_brut_leggings", new CArmor("Diamant Brut Leggings", "diamant_brut_leggings", 8, 5000, ArmorInventory::SLOT_LEGS, "Jambiers en §bDiamant Brut"));
        self::_registryRegister("diamant_brut_boots", new CArmor("Diamant Brut Boots", "diamant_brut_boots", 5, 5000, ArmorInventory::SLOT_FEET, "Bottes en §bDiamant Brut"));

    }
}